// function App() {
//     return (<h1>Hola Mundo</h1>);
// }

// export default App;

export const HelloWorldApp = () => {


  return (
    <h1>Hello World App</h1>
  );
}

// FirstApp  <h1>Fernando</h1>
